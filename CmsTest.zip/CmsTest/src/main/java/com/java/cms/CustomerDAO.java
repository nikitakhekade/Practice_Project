package com.java.cms;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class CustomerDAO {
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<Customer> CustomerShow() {
		String cmd ="select * from Customer ";
		
		List<Customer> customerList = jdbcTemplate.query(cmd, new Object[] {},  new RowMapper<Customer>() {

			@Override
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer.setCUS_ID(rs.getInt("Cus_ID"));
				customer.setCUS_NAME(rs.getString("Cus_NAME"));
				customer.setCUS_PHN_NO(rs.getString("Cus_PHN_NO"));
				customer.setCUS_USERNAME(rs.getString("Cus_USERNAME"));
				customer.setCUS_PASSWORD(rs.getString("Cus_PASSWORD"));
				customer.setCUS_EMAIL(rs.getString("Cus_EMAIL"));

				return customer;
			}
		});
		return customerList;
	
	}
	
	public List<Orders> customerOrders(int custId){
		String cmd ="select * from Orders where CUS_ID=?";
		List<Orders> ordersList = jdbcTemplate.query(cmd,new Object[] {custId}, new RowMapper<Orders> () {
			public Orders mapRow(ResultSet rs, int rowNum) throws SQLException{
				Orders orders =new Orders();
				   orders.setOrderId(rs.getInt("ORD_ID"));
			       orders.setCustomerId(rs.getInt("CUS_ID"));
			       orders.setVendoId(rs.getInt("VEN_ID"));
			       orders.setWalSource(rs.getString("WAL_SOURCE"));
		           orders.setMenuId(rs.getInt("MEN_ID"));
		           orders.setOrderQuantity(rs.getInt("ORD_QUANTITY"));
		           orders.setBillAmount(rs.getDouble("ORD_BILLAMOUNT"));
		           orders.setOrderStatus(OrderStatus.valueOf(rs.getString("ORD_STATUS")));
	               orders.setOrderComments(rs.getString("ORD_COMMENTS"));
	               
				return orders;
			}
			
		});
		return ordersList;
	}
	
	public List<Orders> customerPendingOrder(int custId) {
		String cmd ="select * from orders where Cus_ID=? and ORD_STATUS ='PENDING'";
		List<Orders> ordersList = jdbcTemplate.query(cmd, new Object[] {custId},new RowMapper<Orders> () {
			public Orders mapRow(ResultSet rs, int rowNum) throws SQLException{
				Orders orders =new Orders();
				   orders.setOrderId(rs.getInt("ORD_ID"));
				   orders.setCustomerId(rs.getInt("CUS_ID"));
			       orders.setVendoId(rs.getInt("VEN_ID"));
			       orders.setWalSource(rs.getString("WAL_SOURCE"));
		           orders.setMenuId(rs.getInt("MEN_ID"));
		           orders.setOrderQuantity(rs.getInt("ORD_QUANTITY"));
		           orders.setBillAmount(rs.getDouble("ORD_BILLAMOUNT"));
		           orders.setOrderStatus(OrderStatus.valueOf(rs.getString("ORD_STATUS")));
	               orders.setOrderComments(rs.getString("ORD_COMMENTS"));
	               
				
				return orders;
			}
			
		});
		
		return ordersList;
		
	}
	

	public Customer searchCustomer(int custID) {
		String cmd ="select * from customer where CUS_ID=?";
		List<Customer> customerList = jdbcTemplate.query(cmd, new Object[] {custID},  new RowMapper<Customer>() {

			@Override
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer.setCUS_ID(rs.getInt("Cus_ID"));
				customer.setCUS_NAME(rs.getString("Cus_NAME"));
				customer.setCUS_PHN_NO(rs.getString("Cus_PHN_NO"));
				customer.setCUS_USERNAME(rs.getString("Cus_USERNAME"));
				customer.setCUS_PASSWORD(rs.getString("Cus_PASSWORD"));
				customer.setCUS_EMAIL(rs.getString("Cus_EMAIL"));

				return customer;
			}
		});
		
		  if (customerList.size()==1) {
	            return customerList.get(0);
	        }
	        return null;
		
	}
	
	
	public String customerAuthentication(String user, String pwd) {
		String cmd = "select count(*) cnt from Customer where CUS_UserName=? AND "
				+ " CUS_Password=?";
		List str=jdbcTemplate.query(cmd,new Object[] {user,pwd}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getInt("cnt");
			}
			
		});
		return  str.get(0).toString();
	}
}
