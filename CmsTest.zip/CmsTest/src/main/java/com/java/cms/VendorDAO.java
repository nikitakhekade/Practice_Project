package com.java.cms;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class VendorDAO {
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<Vendor> VendorShow() {
		String cmd ="select * from vendor ";
		
		List<Vendor> vendorList = jdbcTemplate.query(cmd,  new RowMapper<Vendor>() {

			@Override
			public Vendor mapRow(ResultSet rs, int rowNum) throws SQLException {
				Vendor vendor = new Vendor();
				vendor.setVEN_ID(rs.getInt("Ven_ID"));
				vendor.setVEN_NAME(rs.getString("Ven_NAME"));
				vendor.setVEN_PHN_NO(rs.getString("Ven_PHN_NO"));
				vendor.setVEN_USERNAME(rs.getString("Ven_USERNAME"));
			vendor.setVEN_PASSWORD(rs.getString("Ven_PASSWORD"));
			vendor.setVEN_EMAIL(rs.getString("Ven_EMAIL"));

				return vendor;
			}
		});
		return vendorList;
	
	}
	
	
	public List<Orders> vendorPendingOrder(int venId) {
		String cmd ="select * from orders where ORD_STATUS ='PENDING' and VEN_ID=?";
		List<Orders> ordersList = jdbcTemplate.query(cmd, new Object[] {venId},new RowMapper<Orders> () {
			public Orders mapRow(ResultSet rs, int rowNum) throws SQLException{
				Orders orders =new Orders();
				orders.setOrderId(rs.getInt("ORD_ID"));
				orders.setCustomerId(rs.getInt("CUS_ID"));
			       orders.setVendoId(rs.getInt("VEN_ID"));
			       orders.setWalSource(rs.getString("WAL_SOURCE"));
		           orders.setMenuId(rs.getInt("MEN_ID"));
		           orders.setOrderQuantity(rs.getInt("ORD_QUANTITY"));
		           orders.setBillAmount(rs.getDouble("ORD_BILLAMOUNT"));
		           orders.setOrderStatus(OrderStatus.valueOf(rs.getString("ORD_STATUS")));
	               orders.setOrderComments(rs.getString("ORD_COMMENTS"));	
				return orders;
			}
			
		});
		
		return ordersList;
		
	}
	
	public List<Orders> vendorOrders(int vendoId){
		String cmd ="select * from orders where VEN_ID=?";
		List<Orders> ordersList = jdbcTemplate.query(cmd, new Object[] {vendoId},new RowMapper<Orders> () {
			public Orders mapRow(ResultSet rs, int rowNum) throws SQLException{
				Orders orders =new Orders();
				orders.setOrderId(rs.getInt("ORD_ID"));
			       orders.setCustomerId(rs.getInt("CUS_ID"));
			       orders.setVendoId(rs.getInt("VEN_ID"));
			       orders.setWalSource(rs.getString("WAL_SOURCE"));
		           orders.setMenuId(rs.getInt("MEN_ID"));
		           orders.setOrderQuantity(rs.getInt("ORD_QUANTITY"));
		           orders.setBillAmount(rs.getDouble("ORD_BILLAMOUNT"));
		           orders.setOrderStatus(OrderStatus.valueOf(rs.getString("ORD_STATUS")));
	               orders.setOrderComments(rs.getString("ORD_COMMENTS"));				
	               return orders;
			}
			
		});
		return ordersList;
	}
	
	public Vendor vendorSearch(int venId) {
		String cmd ="select * from vendor where ven_id=?";
		List<Vendor> vendorList = jdbcTemplate.query(cmd, new Object[] {venId},  new RowMapper<Vendor>() {

			@Override
			public Vendor mapRow(ResultSet rs, int rowNum) throws SQLException {
			Vendor vendor = new Vendor();
			vendor.setVEN_ID(rs.getInt("Ven_ID"));
			vendor.setVEN_NAME(rs.getString("Ven_NAME"));
			vendor.setVEN_PHN_NO(rs.getString("Ven_PHN_NO"));
			vendor.setVEN_USERNAME(rs.getString("Ven_USERNAME"));
			vendor.setVEN_PASSWORD(rs.getString("Ven_PASSWORD"));
			vendor.setVEN_EMAIL(rs.getString("Ven_EMAIL"));

			return vendor;
		}
	});
		if (vendorList.size()==1) {
			return vendorList.get(0);
		}
	return null;
	}

	public String vendorAuthentication(String user, String pwd) {
		// TODO Auto-generated method stub
		
		String cmd = "select count(*) cnt from vendor where VEN_UserName=? AND "
				+ " VEN_Password=?";
		List str=jdbcTemplate.query(cmd,new Object[] {user,pwd}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getInt("cnt");
			}
			
		});
		return  str.get(0).toString();
	}
	
}

