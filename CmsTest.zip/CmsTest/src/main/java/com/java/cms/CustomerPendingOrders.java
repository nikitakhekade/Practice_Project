package com.java.cms;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerPendingOrders {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer Id");
	    int custId = sc.nextInt();
	   
	   
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/cms/jdbc.xml");
		CustomerDAO dao = (CustomerDAO)ctx.getBean("CustomerDao");
		List<Orders> ordersList = dao.customerPendingOrder(custId);
		for (Orders orders :ordersList) {
			System.out.println(orders);
		}

	}

}
