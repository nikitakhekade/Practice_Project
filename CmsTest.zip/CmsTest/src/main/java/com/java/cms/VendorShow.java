package com.java.cms;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class VendorShow {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/cms/jdbc.xml");
		VendorDAO dao = (VendorDAO)ctx.getBean("VendorDao");
		List<Vendor> vendorList = dao.VendorShow();
		for (Vendor vendor : vendorList) {
			System.out.println(vendor);
		}
	}

}
