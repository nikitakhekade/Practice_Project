package com.java.cms;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/cms/jdbc.xml");
		int opt;
		Scanner sc=new Scanner( System.in);
		
		System.out.println("1.Show Menu");
		System.out.println("2.Orders");
		System.out.println("3.Customer");
		System.out.println("4.Vendor ");
		
		System.out.println("Enter your choice : ");
		opt=sc.nextInt();
		switch(opt){
			case 1:
				
				MenuDAO menuDao = (MenuDAO)ctx.getBean("employDao");
				List<Menu> menuList = menuDao.showMenu();
				for(Menu menu : menuList) { System.out.println(menu); }
			
			case 2:
				int opt1;
				System.out.println("1.Place Order");
				System.out.println("2.Accept or Reject");
				System.out.println("3.Customer Orders");
				System.out.println("4.Vendor Orders");
				System.out.println("5.Customer Pending Orders");
				System.out.println("6.Vendor Pending Orders");

				
				
				System.out.println("Enter your choice : ");
				
			case 3:
				System.out.println("1.Customer Login");
				System.out.println("2.Show Customers");
				System.out.println("3.Customer Orders");
				System.out.println("4.Customer Pending Orders");
				System.out.println("5.Search Customer");
				System.out.println("Enter your choice : ");
				opt1=sc.nextInt();
				
				
				
				switch(opt1){
				
//				case 1:
//					CustomerDAO dao = (CustomerDAO)ctx.getBean("customerDao");
//					dao.customerAuthentication();
//					
//				case 2:
//					List<Customer> customerList = dao.CustomerShow();
//					for(Customer customer : customerList) { System.out.println(customer); }
//					
//					
//				case 3:
//					OrderDAO orderDao = (OrderDAO)ctx.getBean("orderDao");
//					
//					orderDao.placeOrder(null);
//					
//				case 4:
//					dao.customerPendingOrder();
//				case 5:
//					
//					Customer customer = dao.searchCustomer(custId);
//					
					
				}

		
		}

	}

}
