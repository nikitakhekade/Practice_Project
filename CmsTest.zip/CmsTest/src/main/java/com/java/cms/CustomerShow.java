package com.java.cms;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerShow {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/cms/jdbc.xml");
		CustomerDAO dao = (CustomerDAO)ctx.getBean("employDao");
		List<Customer> CustomerList = dao.CustomerShow();
		for (Customer menu : CustomerList) {
			System.out.println(menu);
		}
	}
}
