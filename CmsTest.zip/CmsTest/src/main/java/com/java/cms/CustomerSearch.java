package com.java.cms;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerSearch {
	public static void main(String[] args) {
		int custId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer Id   ");
		custId = sc.nextInt();
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/cms/jdbc.xml");
		CustomerDAO dao = (CustomerDAO)ctx.getBean("CustomerDao");
		Customer customer = dao.searchCustomer(custId);
		if (customer!=null) {
			System.out.println(customer);
		} else {
			System.out.println("*** Record Not Found ***");
		}
		
	}
}
