package com.java.cms;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class VendorSearch {
	public static void main(String[] args) {
		int venId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Vendor Id   ");
		venId = sc.nextInt();
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/cms/jdbc.xml");
		VendorDAO dao = (VendorDAO)ctx.getBean("VendorDao");
		Vendor vendor = dao.vendorSearch(venId);
		if (vendor!=null) {
			System.out.println(vendor);
		} else {
			System.out.println("*** Record Not Found ***");
		}
		
	}
}
