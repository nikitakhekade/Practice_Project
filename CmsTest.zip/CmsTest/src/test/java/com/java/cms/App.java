package com.java.cms;

public class App {

	public static void main(Object object) {
		// TODO Auto-generated method stub
		
	}

}
