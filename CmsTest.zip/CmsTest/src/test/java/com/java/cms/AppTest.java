package com.java.cms;

import org.junit.Test;

public class AppTest {

}
