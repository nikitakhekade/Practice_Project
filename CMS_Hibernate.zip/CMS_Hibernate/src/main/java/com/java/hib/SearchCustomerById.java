package com.java.hib;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class SearchCustomerById {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Id : ");
		int cid=sc.nextInt();
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Query query =s.createQuery("from Customer where cusId="+cid);
		List<Customer> customerList = query.list();
		if (customerList.size()==0) {
			System.out.println("Record Not Found");
		} else {
			Customer customer=customerList.get(0);
			System.out.println(customer);
		}
	}

}
