package com.java.hib;

import com.java.hib.OrderStatus;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orders")
public class Orders {
	
	@Id
	@Column(name="ORD_ID")
	private int orderId;
	
	@Column(name="CUS_ID")
	private int customerId;
	
	@Column(name="VEN_ID")
	private int vendoId;
	
	@Column(name="WAL_SOURCE")
	private String walSource;
	
	@Column(name="MEN_ID")
	private int menuId;
	
	@Column(name="ORD_QUANTITY")
	private int orderQuantity;
	
	@Column(name="ORD_BILLAMOUNT")
	private double billAmount;
	
	@Enumerated(EnumType.STRING)
	@Column(name="ORD_STATUS")
	private OrderStatus orderStatus;
	
	@Column(name="ORD_COMMENTS")
	private String orderComments;
	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getVendoId() {
		return vendoId;
	}
	public void setVendoId(int vendoId) {
		this.vendoId = vendoId;
	}
	public String getWalSource() {
		return walSource;
	}
	public void setWalSource(String walSource) {
		this.walSource = walSource;
	}
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	public OrderStatus getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getOrderComments() {
		return orderComments;
	}
	public void setOrderComments(String orderComments) {
		this.orderComments = orderComments;
	}
	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", customerId=" + customerId + ", vendoId=" + vendoId + ", menuId="
				+ menuId + ", walSource=" + walSource + ", orderQuantity=" + orderQuantity + ", billAmount="
				+ billAmount + ", orderStatus=" + orderStatus + ", orderComments=" + orderComments + "]";
	}
	
	
}
