package com.java.hib;

import java.io.ObjectInputStream.GetField;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;


public class PlaceOrder {
	
	public static void main(String[] args) {
		
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		
		Orders orders = new  Orders();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter CustomerId  ");
		orders.setCustomerId(sc.nextInt());
		int n= orders.getCustomerId();
		System.out.println("Enter VendorId  ");
		orders.setVendoId(sc.nextInt());
		System.out.println("Enter MenuId  ");
		orders.setMenuId(sc.nextInt());
		System.out.println("Enter WalletType  ");
		orders.setWalSource(sc.next());
		System.out.println("Enter Quantity to Order  ");
		orders.setOrderQuantity(sc.nextInt());
		System.out.println("Enter Order Comments   ");
		orders.setOrderComments(sc.next());
		
		
		Session s = sf.openSession();
		Transaction t= s.beginTransaction();
		Query query =s.createQuery("select menuPrice from Menu where menuId=" +orders.getMenuId());		
		double price=(double) query.uniqueResult();
		double billAmount = orders.getOrderQuantity() * price;
		t.commit();
		s.close();
		
		Session s1 = sf.openSession();
		Transaction t1= s1.beginTransaction();
		Wallet wallet = new Wallet();
		Query query1 =s1.createQuery("select walAmount from Wallet where custId=:custId and walSource=:walSource");		
		query1.setInteger("custId", orders.getCustomerId());
		query1.setString("walSource", orders.getWalSource());
		double balance = (double) query1.uniqueResult();
		System.out.println(balance);
		t1.commit();
		s1.close();
		
		Session s2 = sf.openSession();
		Transaction t2= s2.beginTransaction();
		if(billAmount<balance) {
		Query query2=s2.createQuery("select max(orderId)+1 from Orders");
		int id=(int)query2.uniqueResult();
		orders.setOrderId(id);			
		orders.setOrderStatus(OrderStatus.PENDING);	
		orders.setBillAmount(billAmount);
		s2.save(orders);
		System.out.println(orders);
		System.out.println("order placed successfully for Customer Id "+orders.getCustomerId());
		t2.commit();
		s2.close();
		
		
		
		Session s3 = sf.openSession();
		Transaction t3= s3.beginTransaction();
		balance= balance-billAmount;
		wallet.setWalAmount(balance);
		Query query3=s3.createQuery("update Wallet set walAmount=:walAmount where custId=:custId and walSource=:walSource");
		query3.setDouble("walAmount",balance );
		query3.setInteger("custId",n);
		query3.setParameter("walSource", orders.getWalSource());
		query3.executeUpdate();
		t3.commit();
		System.out.println(wallet.getWalAmount());
		s3.close();
		
		}
		
		else
		{
			System.out.println("Insufficient wallet balance....");
		}	

}

}





//query2=s.createQuery("insert into Orders (customerId,vendoId,walSource,menuId,orderQuantity,orderStatus,orderComments)  select customerId,vendoId,walSource,menuId,orderQuantity,orderStatus,orderComments from newOrder");
//query2.setInteger("customerId", orders.getCustomerId());
//query2.setInteger("vendoId", orders.getVendoId());
//query2.setString("walSource", orders.getWalSource());
//query2.setInteger("menuId", orders.getMenuId());
//query2.setInteger("orderQuantity", orders.getOrderQuantity());
//query2.setParameter("orderStatus", orders.getOrderStatus());
//query2.setString("orderComments", orders.getOrderComments());
//int rowsAffected = query2.executeUpdate();