package com.java.hib;

import javax.persistence.Embeddable;

@Embeddable
public enum WalSource {

	PAYTM, CREDIT_CARD, DEBIT_CARD
}
