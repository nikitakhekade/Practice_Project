package com.java.hib;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class CustomerLogin {
	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter Customer email");
		String Cus_email=sc.next();
		System.out.println("Enter Customer Password");
		String Cus_password=sc.next();
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Query query = session.createQuery(
		        "select count(*) from Customer where cusEmail=:cusEmail and cusPassword=:cusPassword");
		query.setString( "cusEmail",Cus_email);
		query.setString("cusPassword",Cus_password);
		Long count = (Long)query.uniqueResult();
		if(count==1) {System.out.println("Login sucessful");}
		if(count==0) {System.out.println("Login failed");}
	}

}
