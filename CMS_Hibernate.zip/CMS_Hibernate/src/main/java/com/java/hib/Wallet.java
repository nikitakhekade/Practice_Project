package com.java.hib;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name="wallet")
public class Wallet {
	
	@Column(name="CUS_ID")
	private int custId;
	
	@Id
	@Column(name="WAL_ID")
	private int walletId;
	
	@Column(name="WAL_AMOUNT")
	private double walAmount;
	
	@Column(name="WAL_SOURCE")
	private String walSource;
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public int getWalletId() {
		return walletId;
	}
	public void setWalletId(int walletId) {
		this.walletId = walletId;
	}
	public double getWalAmount() {
		return walAmount;
	}
	public void setWalAmount(double walAmount) {
		this.walAmount = walAmount;
	}
	public String getWalSource() {
		return walSource;
	}
	public void setWalSource(String walSource) {
		this.walSource = walSource;
	}
	@Override
	public String toString() {
		return "Wallet [custId=" + custId + ", walletId=" + walletId + ", walAmount=" + walAmount + ", walSource="
				+ walSource + "]";
	}
	
	

}
