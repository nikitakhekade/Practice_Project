package com.java.hib;

public enum OrderStatus {
	
	ACCEPTED, DENIED, PENDING

}
