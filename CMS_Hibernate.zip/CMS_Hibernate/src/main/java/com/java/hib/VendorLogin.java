package com.java.hib;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class VendorLogin {
	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter Vendor email");
		String Ven_email=sc.next();
		System.out.println("Enter Vendor Password");
		String Ven_password=sc.next();
		Configuration cfg = new AnnotationConfiguration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Query query = session.createQuery(
		        "select count(*) from Vendor where VEN_EMAIL=:VEN_EMAIL and VEN_PASSWORD=:VEN_PASSWORD");
		query.setString( "VEN_EMAIL",Ven_email);
		query.setString("VEN_PASSWORD",Ven_password);
		Long count = (Long)query.uniqueResult();
		if(count==1) {System.out.println("Login sucessful");}
		if(count==0) {System.out.println("Login failed");}

		
	}
	
}
