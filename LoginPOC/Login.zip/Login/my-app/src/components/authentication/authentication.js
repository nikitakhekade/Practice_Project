import React, {Component} from 'react';
import { withRouter } from './withRouter';
import './authentication.scss'
import axios from 'axios';
import {Link} from "react-router-dom";

// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as authenticationActions from "../../store/authentication/actions";
export class authentication extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {};
    // }
    constructor(props) {
      super(props);
      this.state = {
        userName:'',
        passWord:'',
        result : ''
      };
    }
     
  changeUserName(event) {  
    this.setState({  
        userName: event.target.value
    });  
  }
  changePassword(event) {  
    this.setState({  
        passWord: event.target.value
    });  
  }
  login = () => {
    let user = this.state.userName
    let pwd = this.state.passWord
    axios.get("http://localhost:1123/authenticate/"+user+"/"+pwd)
    .then(response => {
      if (response.data==="1") {
        localStorage.setItem("user",user)
        this.props.navigate("/dashBoard")
      }
      else{
        alert("invalid credentials...")
      }
      console.log(response.data)
    })
  }  
    render() {
      return <div className="component-authentication">   <h1>Please Log In</h1>

      <form>

        <label>

          Username :  

          <input type="text" 
                 value={this.state.userName} 
                 onChange={this.changeUserName.bind(this)} />

        </label>
        <br/>
        <br/>
        <label>

          Password :  

          <input type="password" 
                   value={this.state.passWord}
                   onChange={this.changePassword.bind(this)} />

        </label>
        <br/>
        <br/>
        <div>

        <input type="button" value="Login" onClick={this.login}/>


        </div>
        <div>< Link to="/register">Register New User</Link></div>

      </form>
      
      </div>;

    }
  }
  export default withRouter(authentication);
// export default connect(
//     ({ authentication }) => ({ ...authentication }),
//     dispatch => bindActionCreators({ ...authenticationActions }, dispatch)
//   )( authentication );