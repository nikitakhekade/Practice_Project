import React, {Component} from 'react';
import { Link } from 'react-router-dom';
import './homepage.scss'
import Register from '../register/register';
import Authentication from '../authentication/authentication';
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as homepageActions from "../../store/homepage/actions";
export default class homepage extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {};
    // }
    render() {
      return <div className="component-homepage"> <h1>Welcome to the portal<br/>
        <Link to="/register">Register</Link><br/>
        <Link to="/authentication">Login</Link></h1>
      </div>;
    }
  }
// export default connect(
//     ({ homepage }) => ({ ...homepage }),
//     dispatch => bindActionCreators({ ...homepageActions }, dispatch)
//   )( homepage );