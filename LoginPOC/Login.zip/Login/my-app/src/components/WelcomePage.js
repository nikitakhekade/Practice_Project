import React from 'react'

export default function WelcomePage(props) {
  return (
   <><h1>
   <div>Welcome ,{props.name} {props.role}</div>
   </h1>
   </>
  )
}
