import React, {Component} from 'react';
import './dashboard.scss'
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as dashboardActions from "../../store/dashboard/actions";
export default class dashboard extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {};
    // }
    render() {
      return <div className="component-dashboard">
       Welcome ,
      </div>;
    }
  }
// export default connect(
//     ({ dashboard }) => ({ ...dashboard }),
//     dispatch => bindActionCreators({ ...dashboardActions }, dispatch)
//   )( dashboard );