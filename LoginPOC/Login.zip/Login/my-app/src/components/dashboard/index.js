import dashboard from "./dashboard"
export default dashboard;
