import axios from 'axios';
import React, {Component} from 'react';
import './register.scss'
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  Outlet
} from "react-router-dom";
import Authentication from '../authentication/authentication';
import { withRouter } from '../authentication/withRouter';
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as registerActions from "../../store/register/actions";
export  class register extends Component {
    constructor(props) {
        super(props);
        this.state = {
          name:" ",
          username:" ",
          role:" ",
          email:" ",
          password:" "

        };
      }
        changeName(event) {  
          this.setState({  
              name: event.target.value
          });  
        }
        changeUserName(event) {  
          this.setState({  
              username: event.target.value
          });  
        }
        changeRole(event) {  
          this.setState({  
              role: event.target.value
          });  
        }
        changeEmail(event) {  
          this.setState({  
              email: event.target.value
          });  
        }
        changePassWord(event) {  
          this.setState({  
              password: event.target.value
          });  
        }
        register=()=>{
          axios.post('http://localhost:1123/register',
          { 
            name: this.state.name,
            username: this.state.username,
            role: this.state.role,
            email: this.state.email,
            password: this.state.password
           },)
          .then(res => {
            console.log(res);
            console.log(res.data);
            this.state.result = res.data
            alert(res.data)
            this.props.navigate("/authentication")
          })
        }
        
    render() {
      return <div className="component-register"><h1>Registeration Form</h1>
      
      <form>
        
        <label className="label">Name : </label>
        <input onChange={this.changeName.bind(this)} 
          value={this.state.name} type="text" />
        <br/><br/>
        <label className="label">Username : </label>
        <input onChange={this.changeUserName.bind(this)} 
          value={this.state.username} type="text" />
        <br/>
        <br/>
        
        <label className="label">Role : </label>
        <input onChange={this.changeRole.bind(this)} 
          value={this.state.role} type="text" />
        <br/><br/>
        <label className="label">Email : </label>
        <input onChange={this.changeEmail.bind(this)} 
          value={this.state.email} type="email" />
        
        <br/><br/>

        <label className="label">Password : </label>
        <input onChange={this.changePassWord.bind(this)} 
          value={this.state.password} type="password" />
        <br/><br/>
        <button onClick={this.register}  type="submit">
          Submit
        </button>
      </form>
      
      <div>< Link to="/authentication"><h3> Login</h3></Link></div>
      </div>;
    }
  }
  export default withRouter(register)
// export default connect(
//     ({ register }) => ({ ...register }),
//     dispatch => bindActionCreators({ ...registerActions }, dispatch)
//   )( register );