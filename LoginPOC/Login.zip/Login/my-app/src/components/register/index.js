import register from "./register"
export default register;
