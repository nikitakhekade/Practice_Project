package com.java.loginPage;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class LoginControllerTest {
	
	
	public void testLogin(){
		
	}
}
