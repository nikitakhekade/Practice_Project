package com.java.loginPage;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;



public interface RegisterRepository extends JpaRepository<Register, Integer>{
	
	@Query("select count(*) from Register where username=:username")
	public String preventDuplicate(@Param("username") String username);
}
