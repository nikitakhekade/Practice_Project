package com.java.loginPage;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface loginRepository  extends JpaRepository<login,Integer> {
	
//	@Query("select count(*) from Register where Username=:Username AND Password=:Password")
//	public String authenticate(@Param("Username") String Username,@Param("Password") String Password);
}