package com.java.loginPage;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class RegisterService {

	@Autowired
	RegisterRepository repo;

	

	
	public String registerNewUser(Register register) {
		int cnt=Integer.parseInt(repo.preventDuplicate(register.getUsername()));
		if(cnt==0) {
			repo.save(register);
			
			return "Registered Sucessfully";
			
		}
		
		
		
		return "Unable to register";
		
	}

}
