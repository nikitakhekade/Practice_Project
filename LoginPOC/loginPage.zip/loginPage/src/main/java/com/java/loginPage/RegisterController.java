package com.java.loginPage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class RegisterController {
	
	@Autowired
	RegisterService service;
	
	@CrossOrigin(origins = "http://localhost:4000")
	@PostMapping("/register")
	public String registerNewUser(@RequestBody Register newUser) {
		return service.registerNewUser(newUser);
	}
	
}
