package com.java.loginPage;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Transactional
public class loginService {
	
	
	
	@Autowired
	private loginDAO dao;
	
	
	public String authenticate(String user,String pwd) {
		return dao.authenticate(user, pwd);
	}

}
