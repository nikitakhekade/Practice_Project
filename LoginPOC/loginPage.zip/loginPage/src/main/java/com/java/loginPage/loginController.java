package com.java.loginPage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class loginController {
	
	@Autowired
	private loginService service;
	
	
	
	@CrossOrigin(origins = "http://localhost:4000")
	@RequestMapping("/authenticate/{user}/{pwd}")
	public String authenticate(@PathVariable String user, @PathVariable String pwd) {
		return service.authenticate(user, pwd);
	}


}
