import logo from './logo.svg';
import './App.css';


import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  Outlet
} from "react-router-dom";
import HomePage from './components/homePage/homePage'
import Menu from './components/menu/menu';
import CustomerPendingOrders from './components/customerPendingOrders/customerPendingOrders'
import CustomerOrders from './components/customerOrders/customerOrders'
import CustomerWallet from './components/customerWallet/customerWallet'
import CustomerShow from './components/customerShow/customerShow';
import CustomerDashBoard from './components/customerDashBoard/customerDashBoard';
import CustomerAuthentication from './components/customerAuthentication/customerAuthentication';
import PlaceOrder from './components/placeOrder/placeOrder';
import ShowMenu from './components/showMenu/showMenu';

import VendorAuthentication from './components/vendorAuthentication/vendorAuthentication';
import VendorMenu from './components/vendorMenu/vendorMenu';
import VendorDashBoard from './components/vendorDashBoard/vendorDashBoard';
import VendorOrders from './components/vendorOrders/vendorOrders';
import VendorPendingOrders from './components/vendorPendingOrders/vendorPendingOrders';
import VendorShow from './components/vendorShow/vendorShow';
import AcceptOrRejectOrder from './components/acceptOrRejectOrder/acceptOrRejectOrder';
function App() {
  return (
    <div className="App">
      
      <BrowserRouter>

      <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/customerAuthentication" element={<CustomerAuthentication />} />
      <Route path="/menu" element={<Menu />} />
      <Route path="/customerDashBoard" element={<CustomerDashBoard />} />
        <Route path="/customerShow" element={<CustomerShow />} />
        <Route path="/customerWallet" element={<CustomerWallet />} />
        <Route path="/customerOrders" element={<CustomerOrders />} />
        <Route path="/customerPendingOrders" element={<CustomerPendingOrders />} />
        <Route path="/placeOrder" element={<PlaceOrder />} />
        <Route path="/showMenu" element={<ShowMenu/>}/>

        <Route path="/vendorAuthentication" element={<VendorAuthentication />} />
      <Route path="/vendorMenu" element={<VendorMenu />} />
      <Route path="/vendorDashBoard" element={<VendorDashBoard />} />
      <Route path="/vendorOrders" element={<VendorOrders/>}/>
      <Route path="/vendorPendingOrders" element={<VendorPendingOrders/>}/>
      <Route path="/vendorShow" element={<VendorShow/>}/>
      <Route path="/acceptOrRejectOrder" element={<AcceptOrRejectOrder/>}/>
        </Routes>

        </BrowserRouter>
      {}
    </div>
  );
}

export default App;