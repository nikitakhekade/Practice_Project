import vendorOrders from "./vendorOrders"
export default vendorOrders;
