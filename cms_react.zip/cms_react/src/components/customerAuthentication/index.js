import customerAuthentication from "./customerAuthentication"
export default customerAuthentication;
