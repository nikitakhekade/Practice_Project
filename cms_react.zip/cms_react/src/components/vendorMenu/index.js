import vendorMenu from "./vendorMenu"
export default vendorMenu;
