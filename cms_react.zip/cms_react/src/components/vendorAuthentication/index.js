import vendorAuthentication from "./vendorAuthentication"
export default vendorAuthentication;
