import vendorPendingOrders from "./vendorPendingOrders"
export default vendorPendingOrders;
