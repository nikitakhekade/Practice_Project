import one from "./one"
export default one;
