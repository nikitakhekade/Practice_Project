import React, {Component} from 'react';
import './one.scss'
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as oneActions from "../../store/one/actions";
export default class one extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {};
    // }
    render() {
      return <div className="component-one">Hello! component one</div>;
    }
  }
// export default connect(
//     ({ one }) => ({ ...one }),
//     dispatch => bindActionCreators({ ...oneActions }, dispatch)
//   )( one );