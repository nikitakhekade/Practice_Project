package com.java.jpa;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;


@Repository
public class VendorDAO {

	@Autowired  
    JdbcTemplate jdbc;  
	
	

	public Vendor searchByVendorUserName(String userName) {
		String cmd = "select * from Vendor where Ven_UserName=?";
		List<Vendor> vendorList = jdbc.query(cmd, new Object[] {userName}, new RowMapper<Vendor>() {

			@Override
			public Vendor mapRow(ResultSet rs, int rowNum) throws SQLException {
				Vendor vendor = new Vendor();
				vendor.setVenId(rs.getInt("Ven_ID"));
				vendor.setVenName(rs.getString("Ven_NAME"));
				vendor.setVenPhnNo(rs.getString("Ven_PHN_NO"));
				vendor.setVenUsername(rs.getString("Ven_USERNAME"));
			vendor.setVenPassword(rs.getString("Ven_PASSWORD"));
			vendor.setVenEmail(rs.getString("Ven_EMAIL"));

				return vendor;
			}
		});
		return vendorList.get(0);
	}
	
	
	public String authenticate(String user,String pwd) {
		String cmd = "select count(*) cnt from Vendor where Ven_UserName=? "
				+ " AND Ven_Password=?";
		List str=jdbc.query(cmd,new Object[] {user,pwd}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getInt("cnt");
			}
			
		});
		return str.get(0).toString();
	}
}
