package com.java.jpa;

public enum OrderStatus {
	ACCEPTED, DENIED,PENDING
}
