package com.java.jpa;


import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class OrderService {

	@Autowired
    private OrderRepository repo;
	
	@Autowired
	private OrderDAO dao;
	
	@Autowired 
	private MenuDAO mdao;
	
	@Autowired 
	private WalletDAO wdao;
	
	@Autowired
	private OrderDAO odao;
	
	
	public String getOrderStatus(int orderId, int vendorId) {
		return repo.getOrderStatus(orderId, vendorId);
	}
	
	public int getLatestOrderId() {
		return repo.getLatestOrderId();
	}
	public String acceptOrRejectOrder(int ordId,int venId,String status) {
		Orders orders = odao.searchByOrderId(ordId);
		int vid = orders.getVenId();
		int cid = orders.getCusId();
		String walType = orders.getWalSource();
		double billAmount = orders.getOrdBillamount();
		 String orderStatus = getOrderStatus(ordId, venId);
		
		if (orderStatus.equals("DENIED")) {
			return "Order"+ordId+" is denied";
		} 
		if (vid!=venId) {
			return "You are unauthorized vendor...";
		} 
		if (status.toUpperCase().equals("YES")) {
			return odao.updateStatus(ordId,"ACCEPTED");
		} else {
			odao.updateStatus(ordId, "DENIED");
			wdao.refundWallet(cid, walType, billAmount);
			return "Order Rejected and Amount Refunded...";
		}
	}
	public void pendingTimer(int orderId, int vendorId) {
		Timer timer = new Timer();
		
		timer.schedule(new TimerTask() {
			  @Override
			  public void run() {
				  String orderStatus = getOrderStatus(orderId, vendorId);
				  if(orderStatus.equals("PENDING")) {
					  acceptOrRejectOrder(orderId, vendorId, "NO");
				  }
			  }
			}, 1*60*1000);
	}
	
	public String getVendorAcceptedOrderCount(int vendorId) {
		return repo.getVendorAcceptedOrderCount(vendorId);
	}
	public String placeOrder(Orders order) {
		Menu menu = mdao.searchByMenuId(order.getMenId());
		Wallet wallet = wdao.showCustomerWallet(order.getCusId(), order.getWalSource());
		double balance = wallet.getWalAmount();
		double billAmount = order.getOrdQuantity()*menu.getMenPrice();
		System.out.println(balance);
		System.out.println(billAmount);
		if (balance-billAmount > 0) {
			order.setOrdStatus("PENDING");
			order.setOrdBillamount(order.getOrdQuantity()*menu.getMenPrice());
			repo.save(order);
			//pending(order.getOrdStatus(), order.getCusId(),order.getOrdId());
			wdao.updateWallet(order.getCusId(), order.getWalSource(), billAmount);
			int orderId = getLatestOrderId();
			
			pendingTimer(orderId, order.getVenId());
			return"Order Placed Successfully...and Amount Debited";
			
		}
		return "Insufficient Funds...";
	}
	
	public List<Orders> showVendorPendingOrders(int venId) {
		return dao.showVendorPendingOrders(venId);
	}
	public List<Orders> showVendorOrders(int venId) {
		return dao.showVendorOrders(venId);
	}
	public List<Orders> showCustomerOrders(int custId) {
		return dao.showCustomerOrders(custId);
	}
	public List<Orders> showCustomerPendingOrders(int custId) {
		return dao.showCustomerPendingOrders(custId);
	}
	public Orders search(int orderId) {
		return repo.findById(orderId).get();
	}
	public List<Orders> showOrders() {
		return repo.findAll();
	}
	@Scheduled
	public String pending(String OrdStatus, int CusId, int ordId) {
		Orders orders = odao.searchByOrderId(ordId);
		int vid = orders.getVenId();
		int cid = orders.getCusId();
		String walType = orders.getWalSource();
		double billAmount = orders.getOrdBillamount();
		Timer timer = new Timer();
		TimerTask task= new TimerTask() {
			
			@Override
			public void run() {
				
				if(orders.getOrdStatus()=="PENDING") {
				odao.updateStatus(ordId, "DENIED");
				wdao.refundWallet(cid, walType, billAmount);
				
				}
				timer.cancel();
			}
		};
			if(orders.getOrdStatus()=="DENIED") {
				return "Order Rejected";
			}
			return "Order Accepted";
	}
}
