package com.java.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface OrderRepository extends JpaRepository<Orders, Integer>{

//	List<Orders> customerOrders(int cusId);
//	List<Orders> vendorOrders(int venId);;
	@Query("select count(*) from Orders where venId=:venId and ordStatus='ACCEPTED'")
	public String getVendorAcceptedOrderCount(@Param("venId") int venId);
	
	@Query("select ordStatus from Orders where ordId=:oId and venId=:vId")
	public String getOrderStatus(@Param("oId") int oId, @Param("vId") int vId);
	
	@Query("select max(ordId) from Orders")
	public int getLatestOrderId();
}
