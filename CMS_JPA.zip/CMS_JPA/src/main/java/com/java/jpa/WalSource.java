package com.java.jpa;

public enum WalSource {
	PAYTM, CREDIT_CARD,DEBIT_CARD
}
