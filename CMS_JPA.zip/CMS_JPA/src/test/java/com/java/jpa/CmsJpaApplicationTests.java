package com.java.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
