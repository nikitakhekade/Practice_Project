package com.java.leave;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class LeaveDetailsMain {
	static Scanner sc = new Scanner(System.in);
	static LeaveDetailBAL bal = new LeaveDetailBAL();
	static LeaveDetailsDAO dao = new LeaveDetailsDAO();
	
	public static void main(String[] args) throws LeaveDetailsException {
		int choice;
		do {
			System.out.println(" O P T I O N S");
			System.out.println(" --------------");
			System.out.println(" 1. Show Leave");
			System.out.println(" 2. Search Leaves");
			System.out.println(" 3. Delete Leaves");
			System.out.println(" 4. Update Leaves");
			System.out.println(" 6. Exit");
			System.out.println("Enter Your Choice   ");
			choice = sc.nextInt();
			switch(choice) {
			case 1 : 
					showLeaveDetailsBal();
				break;
			case 2 : 
				searchLeaveDetailsBal();
				break;
			case 3 :
				deleteLeaveDetailsBal();
			case 4 :
				updateLeaveDetailsBal();
			case 6 : 
				return;
			}
		} while(choice!=6);
		
	}
	
	public static void showLeaveDetailsBal() throws LeaveDetailsException{
		List<LeaveDetails> leaveDetails =bal.showLeaveDetailsBal();
		
		if(leaveDetails!=null) {
			for(LeaveDetails leave: leaveDetails) {
				System.out.println(leave);
			}
		}
		else 
			System.out.println("No leaves added");
		
	}
		
	public static void searchLeaveDetailsBal() throws LeaveDetailsException{
		
	}
	
	public static void deleteLeaveDetailsBal() throws LeaveDetailsException{
		List<LeaveDetails> leaveList =bal.showLeaveDetailsBal();
		System.out.println("Leave List : ");
		for(LeaveDetails l:leaveList) {
			System.out.println(l);
		}
		System.out.println("Enter leave no to be deleted : ");
		int no=sc.nextInt();
		leaveList.remove(no);
	
	}	
	
	public static void updateLeaveDetailsBal() throws LeaveDetailsException{
		LeaveDetails leave = new LeaveDetails();
		System.out.println("Enter LeaveId :");
		leave.setLeaveId(sc.nextInt());
		
		System.out.println("Enter Employee Id :");
		leave.setEmpId(sc.nextInt());
		
		System.out.println("Enter leave start date :");
		leave.setLeaveStartDate(ldate());
		
		
		System.out.println("Enter leave end date :");
		leave.setLeaveEndDate(ldate());
		
		System.out.println("Enter number of leave days :");
		leave.setNoOfDays(sc.nextInt());
		
		System.out.println("Enter leave reason :");
		leave.setLeaveReason(sc.next());
	} 
	
	
	public static Date ldate() throws LeaveDetailsException{
		SimpleDateFormat dateInput = new SimpleDateFormat("yyyy-MM-dd");
		Scanner input = new Scanner(System.in);

		String strDate = input.nextLine();

		try
		{
		   Date date = dateInput.parse(strDate);
		  //String s=new SimpleDateFormat("yyyy-MM-dd").format(date);
		   return date;
		} 
		catch (ParseException e) {}
	
		return null;
		
	}
	
	
	
}
