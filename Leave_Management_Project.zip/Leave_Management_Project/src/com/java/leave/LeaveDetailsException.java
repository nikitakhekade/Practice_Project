package com.java.leave;

public class LeaveDetailsException extends Exception {
	
	LeaveDetailsException(String error) {
		super(error);
	}

}
