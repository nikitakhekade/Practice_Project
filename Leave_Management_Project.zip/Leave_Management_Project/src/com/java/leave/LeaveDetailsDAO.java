package com.java.leave;

import java.util.ArrayList;
import java.util.List;

public class LeaveDetailsDAO {
	
static List<LeaveDetails> leaveDetails;
	
	static {
		leaveDetails = new ArrayList<LeaveDetails>();
	}
	
	public List<LeaveDetails> showLeaveDetailsDao() {
		
		return leaveDetails;
	}
	
	public String searchLeaveDetailsDao(LeaveDetails leave) {
		for(LeaveDetails s : leaveDetails) {
			if(s.equals(leave));
			//leaveList.findAny(leave);
		}	
		return "Search is sucessful";
	}
	public List<LeaveDetails> deleteLeaveDetailsDao( LeaveDetails leave) {
		leaveDetails.remove(leave);
		return leaveDetails;
	}
	
	public List<LeaveDetails> updateLeaveDetailsDao(LeaveDetails leave) {
		leaveDetails.add(leave);
		return leaveDetails;
	}
}
