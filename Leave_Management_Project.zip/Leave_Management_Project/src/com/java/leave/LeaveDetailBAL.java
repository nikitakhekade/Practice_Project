package com.java.leave;

import java.util.Calendar;
import java.util.List;



public class LeaveDetailBAL {
	static StringBuilder sb = new StringBuilder();
	static LeaveDetailsDAO dao = new LeaveDetailsDAO();
	
	public List<LeaveDetails> showLeaveDetailsBal() {
		return dao.showLeaveDetailsDao();
	}
	
	public List<LeaveDetails> searchLeaveDetailsBal(LeaveDetails leaveDetails) {
		
		return dao.showLeaveDetailsDao();
	}
	
	public List<LeaveDetails> deleteLeaveDetailsBal(LeaveDetails leave) throws LeaveDetailsException {
		
		if (isValid(leave)==true) {
			return dao.deleteLeaveDetailsDao(leave);
			}
		else
			return null;
	}

	public List<LeaveDetails> updateLeaveDetailsBal(LeaveDetails leave) throws LeaveDetailsException {
		return dao.updateLeaveDetailsDao(leave);
		
	}
	
	Calendar cal = Calendar.getInstance();
//	cal.roll(Calendar.DATE, -1);
//	   
//	
	
	public boolean isValid(LeaveDetails leaveDetails) throws LeaveDetailsException {
		boolean flag=true;
		if (leaveDetails.getLeaveId() < 5) {
			sb.append("Please enter 5 digit LeaveId.\r\n");
			flag = false;
		}
		if (leaveDetails.getEmpId() < 5) {
			sb.append("Please enter 5 digit empId.\r\n");
			flag = false;
		}
		if (leaveDetails.getLeaveStartDate().before(cal.getTime())) {
			sb.append("Please enter the valid date. \r\n");
			flag = false;
		}
		
		if (leaveDetails.getLeaveEndDate().before(cal.getTime())) {
			sb.append("Please enter the valid date. \r\n");
			flag = false;
		}
		
		if (leaveDetails.getLeaveEndDate().before(leaveDetails.getLeaveStartDate())) {
			sb.append("Please enter the valid date. \r\n");
			flag = false;
		}
		
		if (leaveDetails.getLeaveReason().length()< 20000 || leaveDetails.getLeaveReason().length() > 90000) {
			sb.append("Reason must be Between 20000 and 90000...\r\n");
			flag=false;

		
		if (flag==false) {
			throw new LeaveDetailsException(sb.toString());
		}
		
	}
		return flag;
	}

}
