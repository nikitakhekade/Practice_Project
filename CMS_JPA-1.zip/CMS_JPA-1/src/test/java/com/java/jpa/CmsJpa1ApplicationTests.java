package com.java.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsJpa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
