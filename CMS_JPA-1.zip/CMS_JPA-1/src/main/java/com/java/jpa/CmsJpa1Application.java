package com.java.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmsJpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(CmsJpa1Application.class, args);
	}

}
