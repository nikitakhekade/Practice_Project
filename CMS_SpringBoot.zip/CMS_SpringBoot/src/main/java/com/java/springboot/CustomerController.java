package com.java.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
	@Autowired 
	CanteenDAO dao;
	
	@GetMapping(value="/customer")
    public List<Customer> customerShow() {
        return dao.customerShow();
    }
  
    @GetMapping(value="/searchCustomerByUsername/{cusUserName}")
    public Customer searchByCustomerUserName(@PathVariable String cusUserName) {
        return dao.searchByCustomerUserName(cusUserName);
    }
    
    @GetMapping(value="/searchBycusId/{cusId}")
    public Customer searchBycusId(@PathVariable  int cusId){
        return dao.searchBycusId(cusId);
       
    }
    
    @GetMapping(value="/customerOrder/{cusId}")
    public List<Orders> customerOrders(@PathVariable  int cusId){
        return dao.customerOrders(cusId);
       
    }
    
    @GetMapping(value="/cusPendingOrders/{cusId}")
    public List<Orders> customerPendingOrder(@PathVariable  int cusId){
        return dao.customerPendingOrder(cusId);

    }
    
    @GetMapping(value="/showCusotmerWallet/{cusId}")
    public List<Wallet> showCusotmerWallet(@PathVariable  int cusId){
        return dao.showCusotmerWallet(cusId);

    }
    
    @GetMapping(value="/showCusotmerWallet/{walType}/{cusId}")
    public Wallet searchByWalletType(@PathVariable String walType,@PathVariable int cusId){
        return dao.searchByWalletType(walType,cusId);

    }
    
    @GetMapping(value="/customerAuthentication/{username}/{password}")
    public String customerAuthentication(@PathVariable  String username, @PathVariable String password){
        return dao.customerAuthentication(username, password);

    }
}
