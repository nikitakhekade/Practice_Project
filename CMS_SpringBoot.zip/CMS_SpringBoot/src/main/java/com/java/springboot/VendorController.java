package com.java.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VendorController {
	
	@Autowired 
	CanteenDAO dao;
	
	@GetMapping(value="/vendor")
    public List<Vendor> vendorShow() {
        return dao.vendorShow();
    }
	
	 @GetMapping(value="/vendorSearchById/{vendorId}")
	 public Vendor vendorSearchById(@PathVariable int vendorId) {
		 return dao.vendorSearchById(vendorId);
	}
	 
	 
	 @GetMapping(value="/vendorSearchByUsername/{v_UserName}")
	 public Vendor vendorSearchByIUsername(@PathVariable String v_UserName) {
		 return dao.vendorSearchByIUsername(v_UserName);
	 }
	 
	 @GetMapping(value="/vendorOrder/{venId}")
	 public List<Orders> vendorOrders(@PathVariable  int venId){
		 return dao.vendorOrders(venId);
	 }
	    
	 @GetMapping(value="/venPendingOrders/{venId}")
	 public List<Orders> customerPendingOrder(@PathVariable  int venId){
	      return dao.vendorPendingOrder(venId);

	 }
	 
	 @GetMapping(value="/vendorAuthentication/{username}/{password}")
	    public String vendorAuthentication(@PathVariable  String username, @PathVariable String password){
	        return dao.vendorAuthentication(username, password);

	    }
	    
}
