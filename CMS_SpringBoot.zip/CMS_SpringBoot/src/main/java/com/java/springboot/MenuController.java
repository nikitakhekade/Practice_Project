package com.java.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MenuController {
	
	@Autowired 
	CanteenDAO dao;
	
	@GetMapping(value="/menu")
    public List<Menu> menuShow() {
        return dao.showMenu();
    }
	
	@GetMapping(value="/searchByMenuId/{cusMenuId}")
	public Menu searchByMenuId(@PathVariable  int menuId){
		return dao.searchByMenuId(menuId);
	       
	}
	    
}
