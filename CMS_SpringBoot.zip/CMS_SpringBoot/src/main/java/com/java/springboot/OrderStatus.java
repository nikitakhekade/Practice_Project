package com.java.springboot;

public enum OrderStatus {
	ACCEPTED, DENIED, PENDING

}
